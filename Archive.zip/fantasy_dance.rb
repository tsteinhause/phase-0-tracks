class Dancer

	def name (name)
		puts "#{name}"
	end
	
	def pirouette
		puts "*twirls*"
	end
	
	def age(age)
		puts "#{age}"
	end 
	
	def bow
		puts "*bows*"
	end

	def queue_dance_with(dancer_index)

	end

	def leap
		puts "*Jumps across room*"
	end


	dancer_index = ["Mikhail Baryshnikov", "Anna Pavlova"]
end
